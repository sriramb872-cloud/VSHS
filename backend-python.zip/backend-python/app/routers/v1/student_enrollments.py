# backend-python/app/routers/v1/student_enrollments.py
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Request, status, Query
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_roles, get_current_active_user
from app.api.year_context import resolve_year_id
from app.crud import student_enrollment as se_crud, teacher as teacher_crud, student as student_crud
from app.models.student_enrollment import StudentEnrollment
from app.models.section import Section
from app.models.student import Student
from app.models.user import User
from app.core.audit import write_audit_log
from app.models.academic_year import AcademicYear

router = APIRouter(prefix="/student-enrollments", tags=["Student Enrollments"])


def serialize_enrollment(e: StudentEnrollment, attendance_pct: float = None) -> dict:
    student = e.student
    user = student.user if student else None
    grade_id = None
    grade_name = None
    section_name = None
    if e.section:
        section_name = getattr(e.section, "name", None) or getattr(e.section, "section_name", None)
        grade_id = e.section.grade_id
        if e.section.grade:
            grade_name = getattr(e.section.grade, "name", None) or getattr(e.section.grade, "grade_name", None)

    academic_year_name = None
    if e.academic_year:
        academic_year_name = getattr(e.academic_year, "name", None) or getattr(e.academic_year, "year_name", None)

    return {
        "id": e.id,
        "enrollment_id": e.id,
        "student_id": e.student_id,
        "student_name": user.display_name if user else None,
        "full_name": user.display_name if user else None,
        "admission_number": getattr(student, "admission_number", None) if student else None,
        "roll_number": e.roll_number or (getattr(student, "roll_number", None) if student else None),
        "gender": getattr(student, "gender", None) if student else None,
        "grade_id": grade_id,
        "grade_name": grade_name,
        "section_id": e.section_id,
        "section_name": section_name,
        "academic_year_id": e.academic_year_id,
        "academic_year_name": academic_year_name,
        "attendance_percentage": attendance_pct,
        "created_at": getattr(e, "created_at", None),
    }


@router.get("", response_model=List[dict])
def list_enrollments(
    academic_year_id: Optional[int] = None,
    grade_id: Optional[int] = None,
    section_id: Optional[int] = None,
    school_id: Optional[int] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=500),
    request: Request = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    user_role = str(current_user.role).upper()

    if academic_year_id is None:
        academic_year_id = resolve_year_id(db, current_user, request, allow_all=False)
        if academic_year_id is None and user_role != "SUPER_ADMIN":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="academic_year_id is required: no academic year resolved",
            )

    if user_role == "TEACHER":
        teacher = teacher_crud.get_teacher_by_user_id(db, current_user.id)
        if not teacher:
            return []

        # A teacher may see the roster of any section they are legitimately
        # assigned to - as class teacher, through an explicit teacher_subject
        # row, or through a timetable slot. Restricting this to class teachers
        # only meant a subject teacher opened the marks grid for a class they
        # teach and got "No students enrolled", making it impossible to enter
        # marks for their own subject. This mirrors the assignment rules used
        # by MarksService._check_submission_permission.
        allowed_section_ids = teacher_crud.get_assigned_section_ids(db, teacher)

        if not allowed_section_ids:
            return []

        if section_id is not None:
            if section_id not in allowed_section_ids:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You are not assigned to this section",
                )
            allowed_section_ids = {section_id}

        items, attendance_map = se_crud.get_enrollments(
            db,
            school_id=teacher.school_id,
            academic_year_id=academic_year_id,
            grade_id=None,
            section_ids=allowed_section_ids,
            skip=skip,
            limit=limit
        )
        return [serialize_enrollment(i, attendance_map.get(i.student_id)) for i in items]

    target_school_id = current_user.school_id
    if user_role == "SUPER_ADMIN" and school_id:
        target_school_id = school_id

    if not target_school_id and user_role != "SUPER_ADMIN":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="School context missing")

    items, attendance_map = se_crud.get_enrollments(
        db,
        school_id=target_school_id,
        academic_year_id=academic_year_id,
        grade_id=grade_id,
        section_id=section_id,
        skip=skip,
        limit=limit
    )

    return [serialize_enrollment(i, attendance_map.get(i.student_id)) for i in items]


@router.post("", response_model=dict, status_code=status.HTTP_201_CREATED)
def enroll_student(
    payload: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["SUPER_ADMIN", "PRINCIPAL", "TEACHER"]))
):
    user_role = str(current_user.role).upper()
    data = dict(payload)

    if user_role == "TEACHER":
        teacher = teacher_crud.get_teacher_by_user_id(db, current_user.id)
        if not teacher:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Teacher profile not found")
        assigned_sec = db.query(Section).filter(
            Section.class_teacher_id == teacher.id,
            Section.school_id == teacher.school_id
        ).first()
        if not assigned_sec:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You are not assigned as a Class Teacher.")

        student_id = data.get("student_id")
        if not student_id:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="student_id is required")
        student = student_crud.get_student(db, int(student_id))
        if not student or student.school_id != teacher.school_id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found in your school")

        data["section_id"] = assigned_sec.id
    else:
        student_id = data.get("student_id")

    if not student_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="student_id is required")
    student = student_crud.get_student(db, int(student_id))
    if not student:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found")
    if user_role != "SUPER_ADMIN" and student.school_id != current_user.school_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Student does not belong to your school")

    section_id = data.get("section_id")
    if not section_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="section_id is required")
    section = db.query(Section).filter(Section.id == int(section_id)).first()
    if not section:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Section not found")
    if user_role != "SUPER_ADMIN" and section.school_id != current_user.school_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Section does not belong to your school")

    academic_year_id = data.get("academic_year_id")
    if not academic_year_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="academic_year_id is required")
    academic_year = db.query(AcademicYear).filter(AcademicYear.id == int(academic_year_id)).first()
    if not academic_year:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Academic year not found")
    if user_role != "SUPER_ADMIN" and academic_year.school_id != current_user.school_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Academic year does not belong to your school")

    existing = se_crud.get_student_enrollment_by_academic_year(db, int(student_id), int(academic_year_id))
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Student already enrolled for this academic year")

    item = se_crud.create_student_enrollment(db, data)
    return serialize_enrollment(item)


@router.patch("/{enrollment_id}", response_model=dict)
def update_enrollment(
    enrollment_id: int,
    payload: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["SUPER_ADMIN", "PRINCIPAL"])),
):
    item = se_crud.get_student_enrollment(db, enrollment_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Enrollment not found")
    school_id = item.student.school_id if item.student else None
    if str(current_user.role).upper() != "SUPER_ADMIN" and school_id != current_user.school_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    section_id = payload.get("section_id", item.section_id)
    academic_year_id = payload.get("academic_year_id", item.academic_year_id)
    section = db.query(Section).filter(Section.id == section_id).first()
    academic_year = db.query(AcademicYear).filter(AcademicYear.id == academic_year_id).first()
    if not section or not academic_year or section.school_id != school_id or academic_year.school_id != school_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Section and academic year must belong to the student's school")
    action_type = "TRANSFER" if ("section_id" in payload and payload["section_id"] != item.section_id) else "UPDATE"
    write_audit_log(
        db, user_id=current_user.id, school_id=school_id,
        action=action_type, resource_type="StudentEnrollment", resource_id=enrollment_id,
        details={"updates": payload},
    )
    payload.pop("student_id", None)
    return serialize_enrollment(se_crud.update_student_enrollment(db, item, payload))


@router.delete("/{enrollment_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_enrollment(
    enrollment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["SUPER_ADMIN", "PRINCIPAL"]))
):
    item = se_crud.get_student_enrollment(db, enrollment_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Enrollment not found")

    if str(current_user.role).upper() != "SUPER_ADMIN":
        if item.student and item.student.school_id != current_user.school_id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    write_audit_log(
        db, user_id=current_user.id, school_id=item.student.school_id if item.student else None,
        action="DELETE", resource_type="StudentEnrollment", resource_id=enrollment_id,
        details={},
    )
    se_crud.delete_student_enrollment(db, item)
    return None
