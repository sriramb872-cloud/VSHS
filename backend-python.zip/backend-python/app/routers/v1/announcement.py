# app/routers/v1/announcement.py
from typing import Optional
from fastapi import APIRouter, Depends, Query, Request, status
from sqlalchemy.orm import Session
from app.api import deps
from app.api.year_context import resolve_year_id
from app.schemas.announcement import (
    AnnouncementResponse,
    AnnouncementListResponse,
    AnnouncementCreate,
    AnnouncementUpdate,
    AnnouncementStatus,
    AnnouncementAudience,
)
from app.services.announcement import AnnouncementService
from app.models.user import UserModel
from app.core.audit import write_audit_log

router = APIRouter(prefix="/announcements", tags=["Announcements"])


@router.get("/", response_model=AnnouncementListResponse)
def list_announcements(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    audience: Optional[AnnouncementAudience] = None,
    grade_id: Optional[int] = None,
    section_id: Optional[int] = None,
    status_filter: Optional[AnnouncementStatus] = Query(None, alias="status"),
    academic_year_id: Optional[int] = None,
    request: Request = None,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_user),
):
    if academic_year_id is None:
        academic_year_id = resolve_year_id(db, current_user, request)
    items, total = AnnouncementService.list_announcements(
        db,
        skip=skip,
        limit=limit,
        audience=audience,
        grade_id=grade_id,
        section_id=section_id,
        status=status_filter,
        academic_year_id=academic_year_id,
        current_user=current_user,
    )
    return {"total": total, "items": items}

@router.get("/{announcement_id}", response_model=AnnouncementResponse)
def get_announcement(
    announcement_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_user),
):
    return AnnouncementService.get_announcement(db, announcement_id=announcement_id, current_user=current_user)

@router.post("/", response_model=AnnouncementResponse, status_code=status.HTTP_201_CREATED)
def create_announcement(
    obj_in: AnnouncementCreate,
    request: Request = None,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_teacher),
):
    if getattr(obj_in, "academic_year_id", None) is None:
        resolved = resolve_year_id(db, current_user, request, allow_all=False)
        if resolved is not None:
            obj_in = obj_in.model_copy(update={"academic_year_id": resolved})
    result = AnnouncementService.create_announcement(db, obj_in=obj_in, current_user=current_user)
    write_audit_log(db, user_id=current_user.id, school_id=current_user.school_id, action="CREATE", resource_type="Announcement", resource_id=getattr(result, "id", None), details={"title": getattr(result, "title", "")})
    return result

@router.put("/{announcement_id}", response_model=AnnouncementResponse)
def update_announcement(
    announcement_id: int,
    obj_in: AnnouncementUpdate,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.require_roles(["SUPER_ADMIN", "PRINCIPAL", "TEACHER"])),
):
    result = AnnouncementService.update_announcement(db, announcement_id=announcement_id, obj_in=obj_in, current_user=current_user)
    write_audit_log(db, user_id=current_user.id, school_id=current_user.school_id, action="UPDATE", resource_type="Announcement", resource_id=announcement_id)
    return result

@router.delete("/{announcement_id}", response_model=AnnouncementResponse)
def delete_announcement(
    announcement_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.require_roles(["SUPER_ADMIN", "PRINCIPAL", "TEACHER"])),
):
    result = AnnouncementService.delete_announcement(db, announcement_id=announcement_id, current_user=current_user)
    write_audit_log(db, user_id=current_user.id, school_id=current_user.school_id, action="DELETE", resource_type="Announcement", resource_id=announcement_id)
    return result

@router.post("/{announcement_id}/publish", response_model=AnnouncementResponse)
def publish_announcement(
    announcement_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    result = AnnouncementService.publish_announcement(db, announcement_id=announcement_id, current_user=current_user)
    write_audit_log(db, user_id=current_user.id, school_id=current_user.school_id, action="PUBLISH", resource_type="Announcement", resource_id=announcement_id)
    return result

@router.post("/{announcement_id}/archive", response_model=AnnouncementResponse)
def archive_announcement(
    announcement_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    result = AnnouncementService.archive_announcement(db, announcement_id=announcement_id, current_user=current_user)
    write_audit_log(db, user_id=current_user.id, school_id=current_user.school_id, action="ARCHIVE", resource_type="Announcement", resource_id=announcement_id)
    return result
