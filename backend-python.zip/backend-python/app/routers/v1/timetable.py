# app/routers/v1/timetable.py
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy.orm import Session
from app.api import deps
from app.api.year_context import resolve_year_id
from app.schemas.timetable import (
    TimetableResponse,
    TimetableListResponse,
    TimetableCreate,
    TimetableUpdate,
    TimetableCopy,
)
from app.services.timetable import TimetableService
from app.models.user import UserModel
from app.core.audit import write_audit_log

router = APIRouter(prefix="/timetables", tags=["Timetables"])


@router.get("", response_model=TimetableListResponse)
@router.get("/", response_model=TimetableListResponse)
def list_timetables(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=200),
    academic_year_id: Optional[int] = None,
    grade_id: Optional[int] = None,
    section_id: Optional[int] = None,
    teacher_id: Optional[int] = None,
    request: Request = None,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_user),
):
    school_id = current_user.school_id if str(current_user.role).upper() != "SUPER_ADMIN" else None
    role = str(current_user.role).upper()
    if role == "TEACHER":
        from app.models.teacher import Teacher
        teacher = getattr(current_user, "teacher_profile", None) or (
            db.query(Teacher).filter(Teacher.user_id == current_user.id).first()
        )
        if teacher:
            teacher_id = teacher.id
    elif role == "STUDENT" and section_id is None:
        from app.models.student import Student
        from app.models.student_enrollment import StudentEnrollment
        student = db.query(Student).filter(Student.user_id == current_user.id).first()
        if student:
            enrollment_query = db.query(StudentEnrollment).filter(
                StudentEnrollment.student_id == student.id
            )
            if academic_year_id is None:
                resolved = resolve_year_id(db, current_user, request)
                if resolved is not None:
                    enrollment_query = enrollment_query.filter(
                        StudentEnrollment.academic_year_id == resolved
                    )
            enrollment = enrollment_query.order_by(StudentEnrollment.id.desc()).first()
            if enrollment:
                section_id = enrollment.section_id
                academic_year_id = enrollment.academic_year_id

    if academic_year_id is None and role != "STUDENT":
        academic_year_id = resolve_year_id(db, current_user, request)

    items, total = TimetableService.list_timetables(
        db,
        skip=skip,
        limit=limit,
        academic_year_id=academic_year_id,
        grade_id=grade_id,
        section_id=section_id,
        teacher_id=teacher_id,
        school_id=school_id,
    )
    return {"total": total, "items": items}


@router.get("/{timetable_id}", response_model=TimetableResponse)
def get_timetable(
    timetable_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_user),
):
    school_id = current_user.school_id if str(current_user.role).upper() != "SUPER_ADMIN" else None
    return TimetableService.get_timetable(db, timetable_id=timetable_id, school_id=school_id)


@router.post("", response_model=TimetableResponse, status_code=status.HTTP_201_CREATED)
@router.post("/", response_model=TimetableResponse, status_code=status.HTTP_201_CREATED)
def create_timetable(
    obj_in: TimetableCreate,
    request: Request = None,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    school_id = current_user.school_id
    if not school_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="School context missing")
    if getattr(obj_in, "academic_year_id", None) is None:
        resolved = resolve_year_id(db, current_user, request, allow_all=False)
        if resolved is not None:
            obj_in = obj_in.model_copy(update={"academic_year_id": resolved})
    res = TimetableService.create_timetable(db, obj_in=obj_in, school_id=school_id)
    write_audit_log(db, user_id=current_user.id, school_id=school_id, action="CREATE", resource_type="Timetable", resource_id=res["id"], details={})
    return res


@router.put("/{timetable_id}", response_model=TimetableResponse)
@router.patch("/{timetable_id}", response_model=TimetableResponse)
def update_timetable(
    timetable_id: int,
    obj_in: TimetableUpdate,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    school_id = current_user.school_id if str(current_user.role).upper() != "SUPER_ADMIN" else None
    res = TimetableService.update_timetable(db, timetable_id=timetable_id, obj_in=obj_in, school_id=school_id)
    write_audit_log(db, user_id=current_user.id, school_id=school_id, action="UPDATE", resource_type="Timetable", resource_id=timetable_id, details={})
    return res


@router.delete("/{timetable_id}", response_model=TimetableResponse)
def delete_timetable(
    timetable_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    school_id = current_user.school_id if str(current_user.role).upper() != "SUPER_ADMIN" else None
    res = TimetableService.delete_timetable(db, timetable_id=timetable_id, school_id=school_id)
    write_audit_log(db, user_id=current_user.id, school_id=school_id, action="DELETE", resource_type="Timetable", resource_id=timetable_id, details={})
    return res


@router.post("/{timetable_id}/copy", response_model=TimetableResponse, status_code=status.HTTP_201_CREATED)
def copy_timetable(
    timetable_id: int,
    copy_in: TimetableCopy,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    school_id = current_user.school_id if str(current_user.role).upper() != "SUPER_ADMIN" else None
    res = TimetableService.copy_timetable(db, timetable_id=timetable_id, copy_in=copy_in, school_id=school_id)
    write_audit_log(
        db, user_id=current_user.id, school_id=school_id, action="COPY", resource_type="Timetable",
        resource_id=res.get("id") if isinstance(res, dict) else getattr(res, "id", None),
        details={"source_timetable_id": timetable_id},
    )
    return res
