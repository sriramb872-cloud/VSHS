# backend-python/app/routers/v1/grade_subjects.py
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_roles, get_current_active_user
from app.models.user import User
from app.models import GradeSubject
from app.models.grade import Grade
from app.models.subject import Subject
from app.models.teacher import Teacher
from app.core.audit import write_audit_log

router = APIRouter(prefix="/grade-subjects", tags=["Grade Subjects"])


def _assert_grade_in_school(db: Session, current_user: User, grade_id: int) -> None:
    if str(current_user.role).upper() == "SUPER_ADMIN":
        return
    grade = db.query(Grade).filter(Grade.id == grade_id).first()
    if not grade or grade.school_id != current_user.school_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Grade does not belong to your school")


@router.get("", response_model=List[dict])
def list_grade_subjects(
    grade_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    _assert_grade_in_school(db, current_user, grade_id)
    items = db.query(GradeSubject).filter(GradeSubject.grade_id == grade_id).all()
    return [{"id": i.id, "grade_id": i.grade_id, "subject_id": getattr(i, "subject_id", None)} for i in items]


@router.post("", response_model=dict, status_code=status.HTTP_201_CREATED)
def assign_subject_to_grade(
    payload: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["SUPER_ADMIN", "PRINCIPAL"]))
):
    grade_id = payload.get("grade_id")
    subject_id = payload.get("subject_id")
    if not grade_id or not subject_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="grade_id and subject_id are required")

    _assert_grade_in_school(db, current_user, grade_id)

    grade = db.query(Grade).filter(Grade.id == grade_id).first()
    if not grade:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Grade not found")
    effective_school_id = grade.school_id

    subject = db.query(Subject).filter(Subject.id == subject_id).first()
    if not subject or subject.school_id != effective_school_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Subject does not belong to the grade's school",
        )

    teacher_id = payload.get("teacher_id")
    if teacher_id:
        teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
        if not teacher or teacher.school_id != effective_school_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Teacher does not belong to the grade's school",
            )

    existing = db.query(GradeSubject).filter(
        GradeSubject.grade_id == grade_id, GradeSubject.subject_id == subject_id
    ).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Assignment already exists")

    item = GradeSubject(**payload)
    db.add(item)
    db.commit()
    db.refresh(item)
    write_audit_log(
        db, user_id=current_user.id, school_id=current_user.school_id,
        action="CREATE", resource_type="GradeSubject", resource_id=item.id,
        details={"grade_id": item.grade_id, "subject_id": item.subject_id}
    )
    return {"id": item.id, "grade_id": item.grade_id, "subject_id": getattr(item, "subject_id", None)}


@router.delete("/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_grade_subject(
    assignment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["SUPER_ADMIN", "PRINCIPAL"]))
):
    item = db.query(GradeSubject).filter(GradeSubject.id == assignment_id).first()
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Assignment not found")
    _assert_grade_in_school(db, current_user, item.grade_id)
    db.delete(item)
    db.commit()
    write_audit_log(
        db, user_id=current_user.id, school_id=current_user.school_id,
        action="DELETE", resource_type="GradeSubject", resource_id=assignment_id,
        details={"grade_id": item.grade_id, "subject_id": item.subject_id}
    )
    return None