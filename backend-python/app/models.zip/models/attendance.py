# backend-python/app/models/attendance.py
from datetime import datetime, date
from sqlalchemy import Column, Integer,BigInteger, String, Date, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from app.core.database import Base


class Attendance(Base):
    __tablename__ = "attendance"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    student_id = Column(Integer, ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True)
    academic_year_id = Column(Integer, ForeignKey("academic_years.id", ondelete="CASCADE"), nullable=False, index=True)
    grade_id = Column(Integer, ForeignKey("grades.id", ondelete="CASCADE"), nullable=False, index=True)
    section_id = Column(Integer, ForeignKey("sections.id", ondelete="CASCADE"), nullable=False, index=True)
    date = Column(Date, nullable=False, index=True)
    status = Column(String(20), nullable=False)  # PRESENT, ABSENT, LATE, LEAVE
    remarks = Column(String(255), nullable=True)
    marked_by = Column(BigInteger, ForeignKey("teachers.teacher_id", ondelete="SET NULL"), nullable=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    student = relationship("Student", back_populates="attendance_records")
    academic_year = relationship("AcademicYear", back_populates="attendance_records")
    grade = relationship("Grade", back_populates="attendance_records")
    section = relationship("Section", back_populates="attendance_records")
    marked_by_teacher = relationship("Teacher", back_populates="attendance_marked")

    __table_args__ = (
        UniqueConstraint("student_id", "date", name="uq_student_attendance_date"),
    )