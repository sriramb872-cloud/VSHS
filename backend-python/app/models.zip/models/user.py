from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
)
from sqlalchemy.orm import relationship

from app.core.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
        autoincrement=True,
    )

    school_id = Column(
        Integer,
        ForeignKey("schools.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    mobile = Column(
        String(15),
        unique=True,
        index=True,
        nullable=False,
    )

    email = Column(
        String(100),
        unique=True,
        index=True,
        nullable=True,
    )

    password_hash = Column(
        String(255),
        nullable=False,
    )

    display_name = Column(
        String(100),
        nullable=False,
    )

    role = Column(
        Enum(
            "SUPER_ADMIN",
            "PRINCIPAL",
            "TEACHER",
            "STUDENT",
        ),
        nullable=False,
        index=True,
    )

    is_active = Column(
        Boolean,
        nullable=False,
        default=True,
    )

    created_at = Column(
        DateTime,
        default=datetime.utcnow,
        nullable=True,
    )

    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=True,
    )

    school = relationship(
        "School",
        back_populates="users",
    )

    teacher_profile = relationship(
        "Teacher",
        back_populates="user",
        uselist=False,
    )

    student_profile = relationship(
        "Student",
        back_populates="user",
        uselist=False,
    )


UserModel = User