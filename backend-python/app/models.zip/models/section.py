# backend-python/app/models/section.py
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from app.core.database import Base


class Section(Base):
    __tablename__ = "sections"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    school_id = Column(Integer, ForeignKey("schools.school_id", ondelete="CASCADE"), nullable=False, index=True)
    grade_id = Column(Integer, ForeignKey("grades.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(50), nullable=False)  # e.g. "10-A"
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    school = relationship("School", back_populates="sections")
    grade = relationship("Grade", back_populates="sections")
    enrollments = relationship("StudentEnrollment", back_populates="section", cascade="all, delete-orphan")
    homeworks = relationship("Homework", back_populates="section", cascade="all, delete-orphan")
    timetables = relationship("Timetable", back_populates="section", cascade="all, delete-orphan")
    attendance_records = relationship("Attendance", back_populates="section", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("grade_id", "name", name="uq_grade_section_name"),
    )