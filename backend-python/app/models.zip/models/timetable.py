# backend-python/app/models/timetable.py
from datetime import datetime, time
from sqlalchemy import Column, Integer, String,BigInteger, Time, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from app.core.database import Base


class Timetable(Base):
    __tablename__ = "timetables"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    school_id = Column(Integer, ForeignKey("schools.school_id", ondelete="CASCADE"), nullable=False, index=True)
    academic_year_id = Column(Integer, ForeignKey("academic_years.id", ondelete="CASCADE"), nullable=False, index=True)
    grade_id = Column(Integer, ForeignKey("grades.id", ondelete="CASCADE"), nullable=False, index=True)
    section_id = Column(Integer, ForeignKey("sections.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_id = Column(Integer, ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True)
    teacher_id = Column(BigInteger, ForeignKey("teachers.teacher_id", ondelete="SET NULL"), nullable=True, index=True)
    day_of_week = Column(String(20), nullable=False)  # MONDAY, TUESDAY, etc.
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    room_number = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    school = relationship("School", back_populates="timetables")
    academic_year = relationship("AcademicYear", back_populates="timetables")
    grade = relationship("Grade", back_populates="timetables")
    section = relationship("Section", back_populates="timetables")
    subject = relationship("Subject", back_populates="timetables")
    teacher = relationship("Teacher", back_populates="timetables")

    __table_args__ = (
        UniqueConstraint("section_id", "day_of_week", "start_time", name="uq_section_time_slot"),
    )


TimetableModel = Timetable
TimetableEntryModel = Timetable

