# app/routers/v1/calendar_event.py
from typing import Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.api import deps
from app.schemas.calendar_event import (
    CalendarEventResponse,
    CalendarEventListResponse,
    CalendarEventCreate,
    CalendarEventUpdate,
    CalendarEventStatus,
    CalendarEventType,
    CalendarEventAudience,
)
from app.services.calendar_event import CalendarEventService
from app.models.user import UserModel

router = APIRouter(prefix="/calendar-events", tags=["Calendar Events"])


@router.get("/", response_model=CalendarEventListResponse)
def list_calendar_events(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=200),
    event_type: Optional[CalendarEventType] = None,
    audience: Optional[CalendarEventAudience] = None,
    status_filter: Optional[CalendarEventStatus] = Query(None, alias="status"),
    academic_year_id: Optional[int] = None,
    grade_id: Optional[int] = None,
    section_id: Optional[int] = None,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_user),
):
    items, total = CalendarEventService.list_events(
        db,
        skip=skip,
        limit=limit,
        event_type=event_type,
        audience=audience,
        status=status_filter,
        academic_year_id=academic_year_id,
        grade_id=grade_id,
        section_id=section_id,
    )
    return {"total": total, "items": items}

@router.get("/{event_id}", response_model=CalendarEventResponse)
def get_calendar_event(
    event_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_user),
):
    return CalendarEventService.get_event(db, event_id=event_id)

@router.post("/", response_model=CalendarEventResponse, status_code=status.HTTP_201_CREATED)
def create_calendar_event(
    obj_in: CalendarEventCreate,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return CalendarEventService.create_event(db, obj_in=obj_in, current_user=current_user)

@router.put("/{event_id}", response_model=CalendarEventResponse)
def update_calendar_event(
    event_id: int,
    obj_in: CalendarEventUpdate,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return CalendarEventService.update_event(db, event_id=event_id, obj_in=obj_in, current_user=current_user)

@router.delete("/{event_id}", response_model=CalendarEventResponse)
def delete_calendar_event(
    event_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return CalendarEventService.delete_event(db, event_id=event_id, current_user=current_user)

@router.post("/{event_id}/publish", response_model=CalendarEventResponse)
def publish_calendar_event(
    event_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return CalendarEventService.publish_event(db, event_id=event_id, current_user=current_user)

@router.post("/{event_id}/cancel", response_model=CalendarEventResponse)
def cancel_calendar_event(
    event_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return CalendarEventService.cancel_event(db, event_id=event_id, current_user=current_user)