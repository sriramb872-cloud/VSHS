# app/routers/v1/timetable.py
from typing import Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.api import deps
from app.schemas.timetable import (
    TimetableResponse,
    TimetableListResponse,
    TimetableCreate,
    TimetableUpdate,
    TimetableCopy,
)
from app.services.timetable import TimetableService
from app.models.user import UserModel

router = APIRouter(prefix="/timetables", tags=["Timetables"])


@router.get("/", response_model=TimetableListResponse)
def list_timetables(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    academic_year_id: Optional[int] = None,
    grade_id: Optional[int] = None,
    section_id: Optional[int] = None,
    teacher_id: Optional[int] = None,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_user),
):
    items, total = TimetableService.list_timetables(
        db,
        skip=skip,
        limit=limit,
        academic_year_id=academic_year_id,
        grade_id=grade_id,
        section_id=section_id,
        teacher_id=teacher_id,
    )
    return {"total": total, "items": items}

@router.get("/{timetable_id}", response_model=TimetableResponse)
def get_timetable(
    timetable_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_user),
):
    return TimetableService.get_timetable(db, timetable_id=timetable_id)

@router.post("/", response_model=TimetableResponse, status_code=status.HTTP_201_CREATED)
def create_timetable(
    obj_in: TimetableCreate,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return TimetableService.create_timetable(db, obj_in=obj_in)

@router.put("/{timetable_id}", response_model=TimetableResponse)
def update_timetable(
    timetable_id: int,
    obj_in: TimetableUpdate,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return TimetableService.update_timetable(db, timetable_id=timetable_id, obj_in=obj_in)

@router.delete("/{timetable_id}", response_model=TimetableResponse)
def delete_timetable(
    timetable_id: int,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return TimetableService.delete_timetable(db, timetable_id=timetable_id)

@router.post("/{timetable_id}/copy", response_model=TimetableResponse, status_code=status.HTTP_201_CREATED)
def copy_timetable(
    timetable_id: int,
    copy_in: TimetableCopy,
    db: Session = Depends(deps.get_db),
    current_user: UserModel = Depends(deps.get_current_active_principal),
):
    return TimetableService.copy_timetable(db, timetable_id=timetable_id, copy_in=copy_in)